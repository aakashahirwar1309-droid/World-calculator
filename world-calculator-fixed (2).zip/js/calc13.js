
function compressImage() {
  var file = document.getElementById('imgcomp_file').files[0];
  if (!file) { alert("Please select an image first!"); return; }
  var quality = document.getElementById('imgcomp_q').value / 100;
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(function(blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'compressed_' + file.name;
        a.click();
        document.getElementById('imgcomp_val').textContent = "Compressed! Size: " + (blob.size/1024).toFixed(2) + " KB";
        document.getElementById('imgcomp_result').style.display='block';
      }, 'image/jpeg', quality);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function resizeImage() {
  var file = document.getElementById('imgres_file').files[0];
  var nw = parseInt(document.getElementById('imgres_w').value);
  var nh = parseInt(document.getElementById('imgres_h').value);
  if (!file) { alert("Please select an image!"); return; }
  if (!nw || !nh) { alert("Please enter width and height!"); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width = nw;
      canvas.height = nh;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, nw, nh);
      canvas.toBlob(function(blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'resized_' + file.name;
        a.click();
        document.getElementById('imgres_val').textContent = "Resized to " + nw + "x" + nh + " px!";
        document.getElementById('imgres_result').style.display='block';
      }, 'image/jpeg', 0.95);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function convertImage() {
  var file = document.getElementById('imgconv_file').files[0];
  var fmt = document.getElementById('imgconv_format').value;
  if (!file) { alert("Please select an image!"); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(function(blob) {
        var ext = fmt.split('/')[1];
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'converted.' + ext;
        a.click();
        document.getElementById('imgconv_val').textContent = "Converted to " + ext.toUpperCase() + "!";
        document.getElementById('imgconv_result').style.display='block';
      }, fmt, 0.95);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function cropImage() {
  var file = document.getElementById('imgcrop_file').files[0];
  var x = parseInt(document.getElementById('imgcrop_x').value)||0;
  var y = parseInt(document.getElementById('imgcrop_y').value)||0;
  var w = parseInt(document.getElementById('imgcrop_w').value);
  var h = parseInt(document.getElementById('imgcrop_h').value);
  if (!file) { alert("Please select an image!"); return; }
  if (!w || !h) { alert("Please enter crop width and height!"); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, x, y, w, h, 0, 0, w, h);
      canvas.toBlob(function(blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'cropped_' + file.name;
        a.click();
        document.getElementById('imgcrop_val').textContent = "Cropped! " + w + "x" + h + " px";
        document.getElementById('imgcrop_result').style.display='block';
      }, 'image/jpeg', 0.95);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
          }

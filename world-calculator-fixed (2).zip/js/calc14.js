
function rotateImage() {
  var file = document.getElementById('imgrot_file').files[0];
  var angle = parseInt(document.getElementById('imgrot_angle').value);
  if (!file) { alert("Please select an image!"); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d');
      if (angle === 90 || angle === 270) {
        canvas.width = img.height;
        canvas.height = img.width;
      } else {
        canvas.width = img.width;
        canvas.height = img.height;
      }
      ctx.translate(canvas.width/2, canvas.height/2);
      ctx.rotate(angle * Math.PI / 180);
      ctx.drawImage(img, -img.width/2, -img.height/2);
      canvas.toBlob(function(blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'rotated_' + file.name;
        a.click();
        document.getElementById('imgrot_val').textContent = "Rotated " + angle + "°!";
        document.getElementById('imgrot_result').style.display='block';
      }, 'image/jpeg', 0.95);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function addWatermark() {
  var file = document.getElementById('imgwm_file').files[0];
  var text = document.getElementById('imgwm_text').value;
  if (!file || !text) { alert("Please select an image and enter text!"); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      ctx.font = 'bold ' + Math.max(20, img.width/20) + 'px Arial';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.lineWidth = 2;
      ctx.textAlign = 'center';
      ctx.strokeText(text, canvas.width/2, canvas.height - 30);
      ctx.fillText(text, canvas.width/2, canvas.height - 30);
      canvas.toBlob(function(blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'watermarked_' + file.name;
        a.click();
        document.getElementById('imgwm_val').textContent = "Watermark added!";
        document.getElementById('imgwm_result').style.display='block';
      }, 'image/jpeg', 0.95);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function applyFilter() {
  var file = document.getElementById('imgflt_file').files[0];
  var filter = document.getElementById('imgflt_type').value;
  if (!file) { alert("Please select an image!"); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      var ctx = canvas.getContext('2d');
      ctx.filter = filter;
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(function(blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'filtered_' + file.name;
        a.click();
        document.getElementById('imgflt_val').textContent = "Filter applied!";
        document.getElementById('imgflt_result').style.display='block';
      }, 'image/jpeg', 0.95);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function makeTransparent() {
  var file = document.getElementById('imgtbg_file').files[0];
  var colorHex = document.getElementById('imgtbg_color').value;
  var tol = parseInt(document.getElementById('imgtbg_tol').value) || 30;
  if (!file) { alert("Please select an image!"); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    var img = new Image();
    img.onload = function() {
      var canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      var imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      var data = imgData.data;
      var r0 = parseInt(colorHex.substr(1, 2), 16);
      var g0 = parseInt(colorHex.substr(3, 2), 16);
      var b0 = parseInt(colorHex.substr(5, 2), 16);
      for (var i = 0; i < data.length; i += 4) {
        var r = data[i], g = data[i+1], b = data[i+2];
        if (Math.abs(r-r0) < tol && Math.abs(g-g0) < tol && Math.abs(b-b0) < tol) {
          data[i+3] = 0;
        }
      }
      ctx.putImageData(imgData, 0, 0);
      canvas.toBlob(function(blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'transparent_' + file.name.replace(/\.[^.]+$/, '') + '.png';
        a.click();
        document.getElementById('imgtbg_val').textContent = "Background removed! Saved as PNG.";
        document.getElementById('imgtbg_result').style.display='block';
      }, 'image/png');
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
          }

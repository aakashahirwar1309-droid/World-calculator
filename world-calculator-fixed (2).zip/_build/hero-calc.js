/* Safe calculator: no eval(). Recursive-descent parser. Trig functions use degrees. */
(function (root) {
  function evaluate(src) {
    var s = String(src).replace(/\s+/g, ''), i = 0;
    var open = (s.match(/\(/g) || []).length, close = (s.match(/\)/g) || []).length;
    for (; close < open; close++) s += ')';
    function err() { throw new Error('Invalid'); }
    function num() {
      var m = /^\d*\.?\d+(?:e[+-]?\d+)?|^\d+\.?/i.exec(s.slice(i));
      if (!m || /^e/i.test(m[0])) err();
      i += m[0].length; return parseFloat(m[0]);
    }
    function expr() {
      var v = term();
      while (s[i] === '+' || s[i] === '-') { var o = s[i++], r = term(); v = o === '+' ? v + r : v - r; }
      return v;
    }
    function startsFactor() { var c = s[i]; return c !== undefined && (/[\d.(πe√]/.test(c) || /^(sin|cos|tan|log|ln)\(/.test(s.slice(i))); }
    function term() {
      var v = unary();
      for (;;) {
        var c = s[i];
        if (c === '*' || c === '×') { i++; v = v * unary(); }
        else if (c === '/' || c === '÷') { i++; var d = unary(); if (d === 0) throw new Error('Division by zero'); v = v / d; }
        else if (startsFactor()) v = v * unary();
        else return v;
      }
    }
    function unary() {
      if (s[i] === '-') { i++; return -unary(); }
      if (s[i] === '+') { i++; return unary(); }
      return power();
    }
    function power() {
      var b = postfix();
      if (s[i] === '^') { i++; return Math.pow(b, unary()); }
      return b;
    }
    function postfix() {
      var v = primary();
      for (;;) {
        if (s[i] === '!') {
          i++; if (v < 0 || v !== Math.floor(v) || v > 170) throw new Error('Factorial needs an integer from 0 to 170');
          var f = 1; for (var k = 2; k <= v; k++) f *= k; v = f;
        } else if (s[i] === '%') { i++; v = v / 100; }
        else return v;
      }
    }
    function primary() {
      var c = s[i];
      if (c === '(') { i++; var v = expr(); if (s[i] !== ')') err(); i++; return v; }
      if (c === 'π') { i++; return Math.PI; }
      if (c === 'e' && !/^e[+-]?\d/i.test(s.slice(i)) ) { i++; return Math.E; }
      if (c === '√') { i++; var x = s[i] === '(' ? primary() : primary(); if (x < 0) throw new Error('Invalid'); return Math.sqrt(x); }
      var fm = /^(sin|cos|tan|log|ln)\(/.exec(s.slice(i));
      if (fm) {
        i += fm[1].length; var a = primary(), r;
        var rad = a * Math.PI / 180;
        if (fm[1] === 'sin') { r = Math.sin(rad); if (a % 180 === 0) r = 0; }
        else if (fm[1] === 'cos') { r = Math.cos(rad); if ((a - 90) % 180 === 0) r = 0; }
        else if (fm[1] === 'tan') { if ((a - 90) % 180 === 0) throw new Error('Invalid'); r = Math.tan(rad); if (a % 180 === 0) r = 0; }
        else if (fm[1] === 'log') { if (a <= 0) throw new Error('Invalid'); r = Math.log10(a); }
        else { if (a <= 0) throw new Error('Invalid'); r = Math.log(a); }
        return r;
      }
      return num();
    }
    if (!s.length) return 0;
    var out = expr();
    if (i !== s.length) err();
    if (!isFinite(out)) throw new Error('Invalid');
    return parseFloat(out.toPrecision(12));
  }
  root.WCCalc = { evaluate: evaluate };
  if (typeof module !== 'undefined') module.exports = root.WCCalc;
  if (typeof document === 'undefined') return;

  var expr = '', fresh = false, lastAns = 0;
  var disp = document.getElementById('calc-display'), errEl = document.getElementById('calc-error');
  if (!disp) return;
  function show() { disp.textContent = expr || '0'; disp.scrollLeft = disp.scrollWidth; }
  function showErr(m) { errEl.textContent = m; errEl.classList.add('show'); clearTimeout(showErr.t); showErr.t = setTimeout(function () { errEl.classList.remove('show'); }, 3000); }
  function put(v) {
    errEl.classList.remove('show');
    var isOp = /^[+\-×÷*\/^%!]$/.test(v) || v === '^2';
    if (fresh && !isOp) expr = '';
    fresh = false;
    if (v === '*') v = '×'; if (v === '/') v = '÷';
    if (v === 'ans') v = String(lastAns);
    if (v === '^2') v = '^2';
    expr += v; show();
  }
  function equals() {
    if (!expr) return;
    try { var r = evaluate(expr.replace(/\^2/g, '^2')); lastAns = r; expr = String(r); fresh = true; show(); }
    catch (e) { showErr(e.message === 'Invalid' ? 'Invalid input! Please check your calculation.' : e.message); expr = ''; show(); }
  }
  document.querySelectorAll('.calc-widget [data-v]').forEach(function (b) {
    b.addEventListener('click', function () {
      var v = b.getAttribute('data-v');
      if (v === 'AC') { expr = ''; fresh = false; errEl.classList.remove('show'); show(); }
      else if (v === 'BK') { expr = expr.slice(0, -1); show(); }
      else if (v === '=') equals();
      else put(v);
    });
  });
  document.querySelectorAll('.calc-tab').forEach(function (t) {
    t.addEventListener('click', function () {
      var sci = t.getAttribute('data-tab') === 'scientific';
      document.querySelectorAll('.calc-tab').forEach(function (x) { x.setAttribute('aria-selected', x === t ? 'true' : 'false'); });
      document.getElementById('pad-scientific').classList.toggle('active', sci);
    });
  });
  document.addEventListener('keydown', function (e) {
    var tg = e.target.tagName; if (tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT' || e.ctrlKey || e.metaKey || e.altKey) return;
    if (/^[0-9.+\-*\/()%^!]$/.test(e.key)) { put(e.key); e.preventDefault(); }
    else if (e.key === 'Enter' && tg !== 'BUTTON') { equals(); e.preventDefault(); }
    else if (e.key === 'Backspace') { expr = expr.slice(0, -1); show(); }
    else if (e.key === 'Escape') { expr = ''; show(); }
  });
  show();
})(typeof window !== 'undefined' ? window : globalThis);

/* Generates the whole static site into the parent folder.  Run:  node _build/build.js */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = path.resolve(__dirname, '..');
const SITE = (process.env.SITE_URL || 'https://world-calculator.aakashsuryavanshi860.workers.dev').replace(/\/$/, '');
const EMAIL = 'aakashsuryavanshi860@gmail.com', TODAY = '2026-11-23', BRAND = 'World Calculators';
const rd = f => fs.readFileSync(path.join(__dirname, f), 'utf8');
const CATS = JSON.parse(rd('categories.json')), LANGS = JSON.parse(rd('languages.json'));
const CSS = rd('style.css').replace(/\n/g, '');
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const slugify = s => s.toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const write = (rel, txt) => { const p = path.join(ROOT, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, txt); };

/* ---------- 1. Load tools from calc*.js ---------- */
const tools = [];
const stubDoc = { getElementById() { return null; }, querySelector() { return null; }, querySelectorAll() { return []; }, addEventListener() {}, createElement() { return { style: {}, getContext() { return {}; } }; } };
function loadCtx(src) { const c = { document: stubDoc, console, setTimeout() {}, localStorage: { getItem() { return null; } }, navigator: {}, Math, Date }; c.window = c; vm.createContext(c); vm.runInContext(src, c); return c; }
fs.mkdirSync(path.join(ROOT, 'js'), { recursive: true });
for (let n = 1; n <= 18; n++) {
  const src = fs.readFileSync(path.join(__dirname, 'src', `calc${n}.js`), 'utf8');
  const ctx = loadCtx(src), list = ctx['tools' + n], html = ctx['htmls' + n];
  list.forEach(t => tools.push({ file: n, id: t.id, name: t.name, icon: t.icon, html: html[t.id], oldId: t.id }));
  // strip the (duplicated) tool-list/HTML data from the runtime script, but only if nothing else is lost
  const first = src.search(/^\s*function\s/m);
  let js = src;
  if (first > src.indexOf('htmls' + n)) {
    const cand = src.slice(first), c2 = loadCtx(cand);
    const keys = c => Object.keys(c).filter(k => !['tools' + n, 'htmls' + n].includes(k)).sort().join();
    if (keys(ctx) === keys(c2)) js = cand;
  }
  write(`js/calc${n}.js`, js);
}
tools.forEach(t => {
  if (t.file === 17 && t.id === 'urlencode') t.id = 'urlencoder';
  if (t.id === 'pwgen') t.name = 'Secure Password Generator';
});

/* ---------- 2. Categories ---------- */
const KIND = {
  'Financial': { k: 'calc', app: 'FinanceApplication', meta: 'Estimate payments, interest, returns and taxes.', use: 'Use it to estimate payments, interest, returns or taxes before you make a money decision.', note: 'Results are estimates based on the numbers you enter. Rates, fees and taxes differ by country and provider, so confirm final figures with your bank or a qualified advisor.' },
  'Health & Fitness': { k: 'calc', app: 'HealthApplication', meta: 'Quick health, fitness and nutrition estimates.', use: 'Use it for a quick estimate when planning your health, fitness or nutrition goals.', note: 'The result is a general guide, not a medical diagnosis. Talk to a doctor or registered dietitian before making health decisions.' },
  'Math': { k: 'calc', app: 'EducationalApplication', meta: 'Instant answers for study, homework and work.', use: 'Enter your values to get an instant answer for study, homework or work.', note: 'Check units and decimal places in the result, and double-check anything important.' },
  'Everyday Life': { k: 'calc', app: 'UtilitiesApplication', meta: 'Handy for dates, conversions, travel and home projects.', use: 'It is handy for daily tasks such as dates, conversions, travel and home projects.', note: 'Results are estimates based on the values you enter, so verify anything that matters.' },
  'Physics & Engineering': { k: 'calc', app: 'EducationalApplication', meta: 'Quick formulas for students, DIY and engineering estimates.', use: 'It is useful for students, DIY projects and quick engineering estimates.', note: 'Real projects need safety margins and professional verification, so treat the result as a starting point.' },
  'Image Tools': { k: 'file', app: 'MultimediaApplication', meta: 'Edit images privately in your browser.', use: 'Choose an image from your device and it is processed right in your browser.', note: 'Very large images can be slow or run out of memory on older phones; try a smaller file if that happens.' },
  'PDF Tools': { k: 'file', app: 'BusinessApplication', meta: 'Work with PDF files privately in your browser.', use: 'Choose your file(s) and the work happens right in your browser.', note: 'Large or password-protected PDFs may not work and can be slow on older devices.' },
  'Text Tools': { k: 'text', app: 'UtilitiesApplication', meta: 'Clean up and analyse text instantly.', use: 'Type or paste your text and see the result instantly.', note: '' },
  'Developer Tools': { k: 'text', app: 'DeveloperApplication', meta: 'Quick encoders, formatters and generators for developers.', use: 'Paste your input and get the output instantly.', note: '' },
  'QR & Barcode': { k: 'file', app: 'UtilitiesApplication', meta: 'Create and read QR codes in your browser.', use: 'Create or read QR codes directly in your browser.', note: '' },
  'Basic Tools': { k: 'calc', app: 'UtilitiesApplication', meta: 'A simple, fast calculator.', use: 'Enter your numbers and get an instant result.', note: '' }
};
const catList = Object.keys(CATS).map((name, i) => ({ name, i, slug: slugify(name), ...KIND[name], ids: CATS[name] }));
const byId = {}; tools.forEach(t => { byId[t.id] = t; });
const seenSlug = new Set(['about', 'how-it-works', 'why-choose-us', 'contact', 'report-issue', 'privacy-policy', 'terms', 'sitemap', 'js', 'tool', '404', 'favicon']);
catList.forEach(c => c.ids.forEach(id => {
  const t = byId[id]; if (!t) throw new Error('Unknown id in category: ' + id);
  if (t.cat) throw new Error('Tool in two categories: ' + id);
  t.cat = c;
}));
tools.forEach(t => {
  if (!t.cat) throw new Error('Tool without category: ' + t.id);
  t.slug = slugify(t.name); if (seenSlug.has(t.slug)) throw new Error('Slug collision: ' + t.slug); seenSlug.add(t.slug);
});
catList.forEach(c => { if (seenSlug.has(c.slug) && c.slug !== 'math') {/* category anchors live on home only */} });
const catTools = c => c.ids.map(id => byId[id]);

/* ---------- 3. Shared HTML pieces ---------- */
const NAV = [['/', '🏠 Home'], ['/about/', 'ℹ️ About Us'], ['/how-it-works/', '⚙️ How It Works'], ['/why-choose-us/', '🏆 Why Choose Us'], ['/terms/', '📜 Terms & Conditions'], ['/privacy-policy/', '🔒 Privacy Policy'], ['/sitemap/', '🗺️ Sitemap'], ['/contact/', '📞 Customer Support'], ['/report-issue/', '🚩 Report an Issue']];
const FAVICON = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#2563eb"/><rect x="14" y="12" width="36" height="12" rx="3" fill="#fff"/><g fill="#fff"><circle cx="20" cy="34" r="4"/><circle cx="32" cy="34" r="4"/><circle cx="44" cy="34" r="4"/><circle cx="20" cy="47" r="4"/><circle cx="32" cy="47" r="4"/><circle cx="44" cy="47" r="4"/></g></svg>');
const header = () => `<a class="skip-link" href="#main">Skip to main content</a>
<div class="top-bar"><div class="lang-search"><input type="text" id="langSearchInput" placeholder="Search language..." aria-label="Search language"><select id="languageSelect" aria-label="Select language"><option value="">Select Language...</option></select></div><div style="display:flex;gap:15px"><a href="/contact/">Customer Support</a><a href="/report-issue/">Report Issue</a></div></div>
<header class="main-header"><div class="hdr-left"><button type="button" class="menu-btn" id="menu-btn" aria-label="Open menu" aria-expanded="false" aria-controls="sidebar">☰</button><a class="logo" href="/" translate="no">World<span>Calculators</span></a></div><div class="search-bar"><input type="search" id="searchInput" data-search="searchResults" placeholder="Search tools..." aria-label="Search tools" autocomplete="off"><ul class="search-results" id="searchResults"></ul></div></header>
<div class="sidebar-overlay" id="sidebar-overlay"></div>
<nav class="sidebar" id="sidebar" aria-label="Main menu"><div class="sidebar-header"><span>Menu</span><button type="button" class="close-btn" aria-label="Close menu">×</button></div>${NAV.map(([h, t]) => `<a href="${h}">${t}</a>`).join('')}</nav>`;
const footer = () => `<footer><nav aria-label="Footer">${NAV.slice(1).map(([h, t]) => `<a href="${h}">${t.replace(/^[^ ]+ /, '')}</a>`).join('')}</nav><p>© 2026 ${BRAND}. All rights reserved.</p></footer><div id="google_translate_element" style="display:none"></div>`;
function shell(o) {
  const url = SITE + o.path;
  const ld = (o.ld || []).map(x => `<script type="application/ld+json">${JSON.stringify(x).replace(/</g, '\\u003c')}</script>`).join('');
  const libs = (o.libs || []).map(s => `<script defer src="${s}"></script>`).join('');
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${esc(o.title)}</title>
<meta name="description" content="${esc(o.desc)}">${o.noindex ? '<meta name="robots" content="noindex,follow">' : '<meta name="robots" content="index,follow,max-image-preview:large">'}
<link rel="canonical" href="${url}"><link rel="icon" href="${FAVICON}"><meta name="theme-color" content="#0f172a">
<meta property="og:type" content="website"><meta property="og:site_name" content="${BRAND}"><meta property="og:title" content="${esc(o.title)}"><meta property="og:description" content="${esc(o.desc)}"><meta property="og:url" content="${url}"><meta property="og:image" content="${SITE}/og-image.png">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${esc(o.title)}"><meta name="twitter:description" content="${esc(o.desc)}"><meta name="twitter:image" content="${SITE}/og-image.png">
${o.libs && o.libs.length ? '<link rel="preconnect" href="https://cdnjs.cloudflare.com">' : ''}<style>${CSS}</style>${ld}</head>
<body>${header()}
${o.body}
${footer()}
${libs}${(o.scripts || []).map(s => `<script defer src="${s}"></script>`).join('')}<script defer src="/js/site.js"></script></body></html>`;
}

/* ---------- 4. Tool pages ---------- */
function fixHtml(h, name) {
  let n = 0; const labelled = new Set();
  h = h.replace(/<label>([^<]*)<\/label>\s*<(input|select|textarea)\b([^>]*?)(\/?)>/g, (m, txt, tag, attrs, sl) => {
    let id = (/\bid="([^"]+)"/.exec(attrs) || [])[1];
    if (!id) { id = 'f' + (++n); attrs += ` id="${id}"`; }
    labelled.add(id); return `<label for="${id}">${txt}</label><${tag}${attrs}${sl}>`;
  });
  h = h.replace(/<(input|select|textarea)\b([^>]*?)(\/?)>/g, (m, tag, attrs, sl) => {
    const id = (/\bid="([^"]+)"/.exec(attrs) || [])[1];
    if ((id && labelled.has(id)) || /aria-label|type="(hidden|button|submit)"/.test(attrs)) return m;
    return `<${tag}${attrs} aria-label="${esc(name)}"${sl}>`;
  });
  return h.replace(/class="result-box"/g, 'class="result-box" role="status" aria-live="polite"').replace(/<button class="btn"/g, '<button type="button" class="btn"');
}
const COPY = {
  calc: { steps: ['Enter your values in the fields above.', 'Press the button to calculate.', 'Read the result shown under the button, then change a value and calculate again to compare.'] },
  file: { steps: ['Choose your file (or enter your details) using the tool above.', 'Adjust any options and press the action button.', 'Preview or download the result. Nothing is uploaded to a server.'] },
  text: { steps: ['Type or paste your input into the box above.', 'Press the button (some tools update instantly).', 'Copy the result and use it wherever you need it.'] }
};
function pageCopy(t) {
  const c = t.cat, n = t.name, k = c.k;
  const faq = [
    [`Is the ${n} free to use?`, `Yes. The ${n} is completely free. There is no sign-up, no download and no hidden fee.`],
    [`Is my data uploaded or stored?`, t.id === 'notepad' ? 'Your notes are saved only in your own browser (local storage) so they are still there when you come back. They are never sent to our servers.' : `No. The ${n} runs inside your browser, so what you type${k === 'file' ? ' and the files you choose' : ''} stays on your device.`],
    [`Can I use the ${n} on my phone?`, 'Yes. The page is built to work on phones, tablets and computers.']
  ];
  if (k === 'calc') faq.push([`How accurate is the ${n}?`, c.note]);
  const about = [`The ${n} is a free online ${k === 'calc' ? 'calculator' : 'tool'} that works directly in your browser. ${c.use}`];
  if (c.note) about.push(c.note);
  return { about, steps: COPY[k].steps, faq };
}
function related(t) {
  const list = catTools(t.cat), i = list.indexOf(t), out = [];
  for (let d = 1; out.length < 8 && d < list.length; d++) { const x = list[(i + d) % list.length]; if (x !== t) out.push(x); }
  return out;
}
let descWarn = 0;
tools.forEach(t => {
  const c = t.cat, cp = pageCopy(t), path_ = `/${t.slug}/`;
  const title = `${t.name} – Free Online | ${BRAND}`;
  let desc = `Free online ${t.name}. ${c.meta} Works in your browser – no sign-up needed.`;
  if (desc.length > 160) { descWarn++; desc = desc.slice(0, 157) + '…'; }
  const libs = t.file === 15 ? ['https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'] : t.file === 18 ? ['https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js', 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js'] : [];
  const ld = [
    { '@context': 'https://schema.org', '@type': 'WebApplication', name: t.name, url: SITE + path_, description: desc, applicationCategory: c.app, operatingSystem: 'Any', browserRequirements: 'Requires JavaScript', isAccessibleForFree: true, inLanguage: 'en', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' }, publisher: { '@type': 'Organization', name: BRAND, url: SITE + '/' } },
    { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Home', item: SITE + '/' }, { '@type': 'ListItem', position: 2, name: c.name, item: SITE + '/#' + c.slug }, { '@type': 'ListItem', position: 3, name: t.name, item: SITE + path_ }] }
  ];
  const body = `<nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a> › <a href="/#${c.slug}">${esc(c.name)}</a> › <span aria-current="page">${esc(t.name)}</span></nav>
<main id="main" class="tool-wrap"><div class="tool-head" style="text-align:center"><h1>${esc(t.name)}</h1></div>
<section class="tool-box" aria-label="${esc(t.name)}">${fixHtml(t.html, t.name)}</section>
<div class="content"><h2>About the ${esc(t.name)}</h2>${cp.about.map(p => `<p>${esc(p)}</p>`).join('')}
<h2>How to use it</h2><ol>${cp.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol>
<h2>Frequently asked questions</h2><div class="faq">${cp.faq.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}</div>
<h2>More ${esc(c.name)} tools</h2><ul class="related">${related(t).map(x => `<li><a href="/${x.slug}/">${x.icon} ${esc(x.name)}</a></li>`).join('')}</ul></div></main>`;
  write(`${t.slug}/index.html`, shell({ title, desc, path: path_, body, ld, libs, scripts: [`/js/calc${t.file}.js`] }));
});

/* ---------- 5. Home ---------- */
const N = tools.length, nBucket = Math.floor(N / 10) * 10;
const btn = (v, label, cls, aria) => `<button type="button" class="calc-btn ${cls || ''}" data-v="${esc(v)}"${aria ? ` aria-label="${aria}"` : ''}>${label}</button>`;
const sci = [['sin(', 'sin'], ['cos(', 'cos'], ['tan(', 'tan'], ['log(', 'log'], ['ln(', 'ln'], ['π', 'π'], ['e', 'e'], ['√(', '√', 'square root'], ['^2', 'x²', 'square'], ['^', 'x^y', 'power'], ['(', '(', 'open bracket'], [')', ')', 'close bracket'], ['!', 'n!', 'factorial'], ['%', '%', 'percent'], ['1/(', '1/x', 'reciprocal']];
const basic = [['AC', 'AC', 'op', 'Clear all'], ['BK', '⌫', 'op', 'Backspace'], ['%', '%', 'op', 'Percent'], ['/', '÷', 'op', 'Divide'], ['7', '7'], ['8', '8'], ['9', '9'], ['*', '×', 'op', 'Multiply'], ['4', '4'], ['5', '5'], ['6', '6'], ['-', '−', 'op', 'Minus'], ['1', '1'], ['2', '2'], ['3', '3'], ['+', '+', 'op', 'Plus'], ['0', '0'], ['.', '.', '', 'Decimal point'], ['=', '=', 'equal', 'Equals'], ['ans', 'Ans', 'op', 'Previous answer']];
const home = `<main id="main"><section class="hero" id="home-hero"><h1>${BRAND} – Free Online Calculators &amp; Tools</h1><p class="sub">Your global online toolkit – free for everyone!</p>
<div class="calc-widget" role="group" aria-label="Calculator"><div class="calc-tabs" role="tablist"><button type="button" class="calc-tab" role="tab" aria-selected="true" data-tab="basic">Basic</button><button type="button" class="calc-tab" role="tab" aria-selected="false" data-tab="scientific">Scientific</button></div>
<div class="calc-display" id="calc-display" role="status" aria-live="polite">0</div><div class="calc-error" id="calc-error" role="alert"></div>
<div class="calc-sci-pad" id="pad-scientific">${sci.map(s => btn(s[0], s[1], 'sci', s[2])).join('')}</div>
<div class="calc-pad">${basic.map(b => btn(b[0], b[1], b[2], b[3])).join('')}</div></div>
<div class="hero-search"><input type="search" id="toolSearchHero" data-search="heroSearchResults" placeholder="🔍 Search any calculator or tool..." aria-label="Search any calculator or tool" autocomplete="off"><ul class="search-results" id="heroSearchResults"></ul></div></section>
<div class="container">${catList.map(c => `<section aria-labelledby="h-${c.slug}"><h2 class="cat-title" id="${c.slug}"><span id="h-${c.slug}">${esc(c.name)}</span></h2><div class="tool-grid">${catTools(c).map(t => `<a class="tool-card" href="/${t.slug}/"><span class="icon" aria-hidden="true">${t.icon}</span><span class="name">${esc(t.name)}</span></a>`).join('')}</div></section>`).join('')}</div>
<section class="intro"><h2>Free online calculators and tools for everyone</h2><p>${BRAND} brings ${nBucket}+ free tools together in one place: financial and loan calculators, health and fitness calculators, math and unit conversions, everyday helpers, image and PDF tools, text utilities and developer tools. Every tool has its own page, opens instantly and works in your browser, so there is nothing to install and no account to create. You can switch the page to more than 100 languages from the language menu at the top.</p></section></main>`;
const homeLd = [{ '@context': 'https://schema.org', '@type': 'WebSite', name: BRAND, url: SITE + '/', inLanguage: 'en' }, { '@context': 'https://schema.org', '@type': 'Organization', name: BRAND, url: SITE + '/', email: EMAIL }];
write('index.html', shell({ title: `${BRAND} – ${nBucket}+ Free Online Calculators & Tools`, desc: 'Free online calculators and tools: financial, health, math, unit conversion, image, PDF, text and developer tools. Fast, private and no sign-up.', path: '/', body: home, ld: homeLd, scripts: ['/js/hero-calc.js'] }));

/* ---------- 6. Static pages ---------- */
const mail = `<a href="mailto:${EMAIL}">${EMAIL}</a>`;
const PAGES = [
  ['about', 'About Us', `Learn about ${BRAND}, a free collection of online calculators and tools.`, `<p>Welcome to <strong>${BRAND}</strong>, a free collection of ${nBucket}+ online calculators and tools. We built it so that anyone, anywhere can get a quick, reliable answer without installing an app or creating an account.</p><h2>What you will find here</h2><p>Financial and loan calculators, health and fitness calculators, math and unit conversions, everyday helpers, physics and engineering formulas, image and PDF tools, text utilities, developer tools and a QR code generator and scanner. Each tool has its own page and web address, so you can bookmark or share exactly the tool you need.</p><h2>How we work</h2><p>The tools run inside your browser. Calculations, images, PDFs and text are processed on your own device rather than being sent to our servers. See our <a href="/privacy-policy/">Privacy Policy</a> for details.</p><h2>Get in touch</h2><p>Found a bug or have a suggestion for a new tool? Email us at ${mail} or use the <a href="/report-issue/">Report an Issue</a> page.</p>`],
  ['how-it-works', 'How It Works', `How to find and use the free tools on ${BRAND}.`, `<ol><li><strong>Search or browse:</strong> use the search box or pick a category on the home page to find a tool.</li><li><strong>Open the tool:</strong> every tool has its own page and web address.</li><li><strong>Enter your details:</strong> fill in the fields, choose a file or paste your text.</li><li><strong>Get instant results:</strong> tools run in your browser, so results appear immediately and your data stays on your device.</li></ol><p>Tip: press the ☰ menu button for quick links, or use the language menu at the top to translate the page.</p>`],
  ['why-choose-us', 'Why Choose World Calculators?', `Why people use ${BRAND}: free, private, fast tools in over 100 languages.`, `<ul><li><strong>Free:</strong> no subscriptions, sign-ups or hidden charges.</li><li><strong>Private by design:</strong> calculations and file processing happen on your device.</li><li><strong>Fast:</strong> pages are lightweight and load only the code each tool needs.</li><li><strong>One page per tool:</strong> easy to bookmark and share.</li><li><strong>Many languages:</strong> switch to more than 100 languages with one click, using Google Translate.</li><li><strong>Works everywhere:</strong> phone, tablet or computer.</li></ul>`],
  ['contact', 'Customer Support', `Contact ${BRAND} for help, feedback or tool suggestions.`, `<p>Questions, feedback or ideas for a new tool? We would love to hear from you.</p><p><strong>Email:</strong> ${mail}</p><p>Please include the name of the tool and, if something does not work, the device and browser you are using. We read every message, although replies can take a few days.</p>`],
  ['report-issue', 'Report an Issue', `Report a bug or wrong result on ${BRAND}.`, `<p>Found a bug or a result that looks wrong? Please let us know.</p><p><strong>Email:</strong> ${mail}</p><p>To help us fix it quickly, include: the tool name or web address, the values you entered, the result you expected and the result you got, and your device and browser.</p>`],
  ['privacy-policy', 'Privacy Policy', `How ${BRAND} handles your data. Calculations and files stay in your browser.`, `<p><em>Last updated: 23 November 2026.</em></p><h2>Your calculations and files</h2><p>The calculators, image tools, PDF tools, text tools and developer tools run inside your browser. The numbers you enter, the text you type and the files you choose are processed on your device and are not uploaded to our servers.</p><h2>Information stored on your device</h2><ul><li>If you choose a language, we remember it using your browser's local storage and a <code>googtrans</code> cookie so the next page opens in the same language.</li><li>The Notepad tool saves your notes in your browser's local storage so they are still there next time. They stay on your device.</li></ul><h2>Third-party services</h2><ul><li><strong>Google Translate:</strong> loaded only when you choose a language other than English. The text of the page is then sent to Google for translation under Google's own privacy policy.</li><li><strong>Script libraries:</strong> PDF and QR tools load open-source libraries from public CDNs (cdnjs and jsDelivr) when you open those tools. These providers may receive your IP address, as with any web request.</li><li><strong>Hosting:</strong> the site is hosted on Cloudflare, which may keep standard server logs such as IP address and browser type for security and operation.</li></ul><h2>Analytics and advertising</h2><p>At the time of writing this site does not run advertising or analytics scripts. If that changes, this policy will be updated first.</p><h2>Children</h2><p>The site is not directed at children under 13 and we do not knowingly collect personal information from them.</p><h2>Contact</h2><p>Questions about this policy? Email ${mail}.</p>`],
  ['terms', 'Terms & Conditions', `Terms of use for ${BRAND}.`, `<p><em>Last updated: 23 November 2026.</em></p><h2>Use of the site</h2><p>By using ${BRAND} you agree to these terms. The site and its tools are provided free of charge for personal, educational and general business use.</p><h2>No professional advice</h2><p>Our tools are provided for informational and educational purposes only. Results are estimates and may contain errors. We are not responsible for any financial, health, legal or engineering decisions made from the results. Please consult a qualified professional before acting on them.</p><h2>No warranty</h2><p>The site is provided "as is" without warranties of any kind. We do not guarantee that it will be uninterrupted or error-free.</p><h2>Limitation of liability</h2><p>To the fullest extent allowed by law, we are not liable for any loss or damage arising from your use of the site or its tools.</p><h2>Acceptable use</h2><p>Do not misuse the site, attempt to disrupt it, or use it for unlawful purposes. You are responsible for the files and content you process with the tools.</p><h2>Changes</h2><p>We may update the tools and these terms from time to time. Continued use means you accept the updated terms.</p><h2>Contact</h2><p>Email ${mail}.</p>`]
];
PAGES.forEach(([slug, h1, desc, html]) => write(`${slug}/index.html`, shell({ title: `${h1} – ${BRAND}`, desc, path: `/${slug}/`, body: `<main id="main"><div class="page-box"><h1>${esc(h1)}</h1>${html}<p><a href="/">← Back to all tools</a></p></div></main>`, scripts: [] })));
const smBody = `<main id="main"><div class="page-box"><h1>Sitemap</h1><h2>Pages</h2><ul class="sitemap-list"><li><a href="/">Home</a></li>${PAGES.map(p => `<li><a href="/${p[0]}/">${esc(p[1])}</a></li>`).join('')}</ul>${catList.map(c => `<h2>${esc(c.name)}</h2><ul class="sitemap-list">${catTools(c).map(t => `<li><a href="/${t.slug}/">${esc(t.name)}</a></li>`).join('')}</ul>`).join('')}</div></main>`;
write('sitemap/index.html', shell({ title: `Sitemap – ${BRAND}`, desc: `All pages and tools on ${BRAND}.`, path: '/sitemap/', body: smBody }));
write('404.html', shell({ title: `Page not found – ${BRAND}`, desc: 'This page could not be found.', path: '/404/', noindex: true, body: `<main id="main"><div class="page-box"><h1>Page not found</h1><p>Sorry, we could not find that page. Try searching for a tool above, or go to the <a href="/">home page</a> or the <a href="/sitemap/">sitemap</a>.</p></div></main>` }));
write('tool.html', shell({ title: `${BRAND}`, desc: 'Redirecting to the tool page.', path: '/', noindex: true, body: `<main id="main"><div class="page-box"><h1>Redirecting…</h1><p>If nothing happens, <a href="/">go to the home page</a>.</p></div></main>` }));

/* ---------- 7. site.js, hero-calc.js, sitemap, robots, config ---------- */
const old = {}; tools.forEach(t => { if (!old[t.oldId]) old[t.oldId] = t.slug; }); old.urlenc = byId.urlencode.slug; old.urldec = byId.urldecode.slug;
const data = { tools: tools.map(t => ({ n: t.name, s: t.slug, i: t.icon })), langs: LANGS, old };
write('js/site.js', rd('site.tpl.js').replace('__DATA__', JSON.stringify(data)));
write('js/hero-calc.js', rd('hero-calc.js'));
const urls = ['/', ...PAGES.map(p => `/${p[0]}/`), '/sitemap/', ...tools.map(t => `/${t.slug}/`)];
const sm = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u => `<url><loc>${SITE}${u}</loc><lastmod>${TODAY}</lastmod></url>`).join('\n')}\n</urlset>\n`;
write('sitemap.xml', sm); write('sitemap_fixed.xml', sm);
write('robots.txt', `User-agent: *\nAllow: /\n\nSitemap: ${SITE}/sitemap.xml\n`);
write('_headers', `/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()
  Cross-Origin-Opener-Policy: same-origin
  Strict-Transport-Security: max-age=31536000
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net https://translate.google.com https://translate.googleapis.com https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://www.gstatic.com https://translate.googleapis.com; img-src 'self' data: blob: https:; font-src 'self' data:; connect-src 'self' https://translate.googleapis.com https://translate-pa.googleapis.com https://cdnjs.cloudflare.com; worker-src 'self' blob: https://cdnjs.cloudflare.com; frame-src https://translate.google.com https://translate.googleapis.com; frame-ancestors 'none'; base-uri 'self'; object-src 'none'; form-action 'self'
`);
write('wrangler.jsonc', `{\n  "name": "world-calculator",\n  "compatibility_date": "2026-11-01",\n  "assets": { "directory": "./", "html_handling": "auto-trailing-slash", "not_found_handling": "404-page" }\n}\n`);
write('.assetsignore', `_build\nwrangler.jsonc\nREADME.md\n.assetsignore\nnode_modules\n`);
console.log(`built ${tools.length} tool pages, ${PAGES.length + 3} other pages, ${urls.length} sitemap urls, ${descWarn} long descriptions`);

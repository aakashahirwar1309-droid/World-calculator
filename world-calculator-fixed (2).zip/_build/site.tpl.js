(function () {
  var D = __DATA__;
  var $ = function (s, r) { return (r || document).querySelector(s); };

  /* ---- Old links (#bmi, /tool.html?tool=bmi) -> new URLs ---- */
  function oldRedirect() {
    var oldId = '';
    if (location.pathname === '/' && location.hash.length > 1) oldId = location.hash.slice(1);
    if (location.pathname === '/tool.html') { oldId = new URLSearchParams(location.search).get('tool') || ''; if (!oldId) { location.replace('/'); return true; } }
    if (oldId && D.old[oldId]) { location.replace('/' + D.old[oldId] + '/'); return true; }
    return false;
  }
  if (oldRedirect()) return;
  window.addEventListener('hashchange', oldRedirect);

  /* ---- Menu ---- */
  var sb = $('#sidebar'), ov = $('#sidebar-overlay'), mb = $('#menu-btn');
  function menu(open) {
    sb.classList.toggle('open', open); ov.classList.toggle('open', open);
    mb.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) $('.close-btn', sb).focus(); else mb.focus();
  }
  mb.addEventListener('click', function () { menu(!sb.classList.contains('open')); });
  ov.addEventListener('click', function () { menu(false); });
  $('.close-btn', sb).addEventListener('click', function () { menu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { if (sb.classList.contains('open')) menu(false); document.querySelectorAll('.search-results.show').forEach(function (u) { u.classList.remove('show'); }); } });

  /* ---- Search (header + home hero) ---- */
  document.querySelectorAll('[data-search]').forEach(function (inp) {
    var ul = document.getElementById(inp.getAttribute('data-search'));
    inp.addEventListener('input', function () {
      var q = inp.value.trim().toLowerCase();
      ul.innerHTML = '';
      if (!q) { ul.classList.remove('show'); return; }
      var m = D.tools.filter(function (t) { return t.n.toLowerCase().indexOf(q) !== -1; }).slice(0, 10);
      if (!m.length) { var li = document.createElement('li'); li.className = 'none'; li.textContent = 'No tools found'; ul.appendChild(li); }
      m.forEach(function (t) {
        var li = document.createElement('li'), a = document.createElement('a');
        a.href = '/' + t.s + '/'; a.textContent = t.i + ' ' + t.n; li.appendChild(a); ul.appendChild(li);
      });
      ul.classList.add('show');
    });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { var a = ul.querySelector('a'); if (a) location.href = a.href; } });
  });
  document.addEventListener('click', function (e) {
    if (!e.target.closest('[data-search],.search-results')) document.querySelectorAll('.search-results.show').forEach(function (u) { u.classList.remove('show'); });
  });

  /* ---- Language (Google Translate is loaded only when needed) ---- */
  var sel = $('#languageSelect'), lsi = $('#langSearchInput');
  var codes = Object.keys(D.langs).sort(function (a, b) { return D.langs[a].localeCompare(D.langs[b]); });
  function fill(f) {
    f = (f || '').toLowerCase(); var cur = sel.value;
    sel.innerHTML = '<option value="">Select Language...</option>';
    codes.forEach(function (c) {
      if (D.langs[c].toLowerCase().indexOf(f) === -1) return;
      var o = document.createElement('option'); o.value = c; o.textContent = D.langs[c]; sel.appendChild(o);
    });
    sel.value = cur;
  }
  fill(); lsi.addEventListener('input', function () { fill(lsi.value); });
  var gtLoaded = false;
  function cookie(v) { document.cookie = 'googtrans=' + v + ';path=/'; }
  window.googleTranslateElementInit = function () {
    new google.translate.TranslateElement({ pageLanguage: 'en', autoDisplay: false }, 'google_translate_element');
    var tries = 0, t = setInterval(function () {
      var c = $('.goog-te-combo'); tries++;
      if (c && wanted) { c.value = wanted; c.dispatchEvent(new Event('change')); clearInterval(t); }
      if (tries > 40) clearInterval(t);
    }, 150);
  };
  var wanted = '';
  function loadGT() {
    if (gtLoaded) return; gtLoaded = true;
    var s = document.createElement('script'); s.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit'; document.head.appendChild(s);
  }
  sel.addEventListener('change', function () {
    var c = sel.value; if (!c) return;
    try { localStorage.setItem('wc_lang', c); } catch (e) {}
    if (c === 'en') { cookie('/en/en;expires=Thu, 01 Jan 1970 00:00:00 GMT'); location.reload(); return; }
    wanted = c; cookie('/en/' + c);
    if (gtLoaded) { var g = $('.goog-te-combo'); if (g) { g.value = c; g.dispatchEvent(new Event('change')); } } else loadGT();
  });
  try { var sv = localStorage.getItem('wc_lang'); if (sv && sv !== 'en') { wanted = sv; sel.value = sv; cookie('/en/' + sv); loadGT(); } } catch (e) {}

  /* ---- PDF.js worker (needed for PDF to JPG) ---- */
  if (window.pdfjsLib && pdfjsLib.GlobalWorkerOptions) pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
})();
